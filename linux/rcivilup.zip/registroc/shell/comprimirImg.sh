#!/bin/bash
convert $1$2 -depth 1 -compress LZW   $1$3
	if [ $? -eq 0 ]
	then
		exit 0;
	else
		exit 99
	fi
