#!/bin/bash
rc_nameRegistro=registroc
source $HOME/$rc_nameRegistro/conf/conf-shell.sh
#convert $HOME/$rc_nameRegistro/tmp/$1.tiff  -compress LZW  -crop $rc_crop_acta -lat $rc_acta_lat $HOME/$rc_nameRegistro/tmp/$1-find.png
#rem %1 es la cantidad %2 blanco %3 size
#rem  %4 blanco %5 size
cantidad=$1
ab=$3
let ab1=$2/10
x="x"
menos="-"
por="%"
lat=$ab$x$ab$menos$ab1$por
#echo $lat > $HOME/$rc_nameRegistro/tmpMarg/a
rm $HOME/$rc_nameRegistro/tmpMarg/im1.json
rm $HOME/$rc_nameRegistro/tmpMarg/im2.json
convert $HOME/$rc_nameRegistro/tmpMarg/im1.jpg -lat $lat $HOME/$rc_nameRegistro/tmpMarg/sal1.png
base64 $HOME/$rc_nameRegistro/tmpMarg/sal1.png > $HOME/$rc_nameRegistro/tmpMarg/im1.json 
if [ $1 -eq 2 ]
then 
	ab=$5
	let ab1=$4/10
	lat=$ab$x$ab$menos$ab1$por
    #    echo $lat > $HOME/$rc_nameRegistro/tmpMarg/b
	convert $HOME/$rc_nameRegistro/tmpMarg/im2.jpg -lat $lat $HOME/$rc_nameRegistro/tmpMarg/sal2.png
	base64 $HOME/$rc_nameRegistro/tmpMarg/sal2.png > $HOME/$rc_nameRegistro/tmpMarg/im2.json 
	exit 0 
else
	exit 0
fi
