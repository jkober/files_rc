#!/bin/bash
rc_nameRegistro=registroc
source $HOME/$rc_nameRegistro/conf/conf-shell.sh
#convert $HOME/$rc_nameRegistro/tmp/$1.tiff  -compress LZW  -crop $rc_crop_acta -lat $rc_acta_lat $HOME/$rc_nameRegistro/tmp/$1-find.png
#rem %1 es la cantidad %2 blanco %3 size
#rem  %4 blanco %5 size
cantidad=$1
tipo=$2
#rem tipo1 sirve por si se tiene que hacer algo especial con el tipo de gris
ab=$4
let ab1=$3
x="%,"
menos=",1"
por="%"
lat=$ab$x$ab1$x$menos
rm $HOME/$rc_nameRegistro/tmpMarg/im1.json
rm $HOME/$rc_nameRegistro/tmpMarg/im2.json
if [ "$tipo" = "im_p_2"]
then
	convert $HOME/$rc_nameRegistro/tmpMarg/im1.jpg -lat $lat -depth 1 $HOME/$rc_nameRegistro/tmpMarg/sal1.png
else 
	convert $HOME/$rc_nameRegistro/tmpMarg/im1.jpg -level $lat -density 72 -units PixelsPerInch -depth 8 -set colorspace Gray -separate -average $HOME/$rc_nameRegistro/tmpMarg/sal1.png
fi
base64 $HOME/$rc_nameRegistro/tmpMarg/sal1.png > $HOME/$rc_nameRegistro/tmpMarg/im1.json 
if [ $1 -eq 2 ]
then 
	tipo=$5
	ab=$7
	let ab1=$6
	lat=$ab$x$ab1$x$menos

    #    echo $lat > $HOME/$rc_nameRegistro/tmpMarg/b
	if [ "$tipo" = "im_p_2"]
	then
		convert $HOME/$rc_nameRegistro/tmpMarg/im2.jpg -lat $lat -depth 1 $HOME/$rc_nameRegistro/tmpMarg/sal2.png
	else 
		convert $HOME/$rc_nameRegistro/tmpMarg/im2.jpg -level $lat -density 72 -units PixelsPerInch -depth 8 -set colorspace Gray -separate -average $HOME/$rc_nameRegistro/tmpMarg/sal2.png
	fi
	base64 $HOME/$rc_nameRegistro/tmpMarg/sal2.png > $HOME/$rc_nameRegistro/tmpMarg/im2.json 
	exit 0 
else
	exit 0
fi
