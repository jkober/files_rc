rc_escanerPort=
# En algun momento el nombre del escaner podria ir ente ' comilla simple
# rc_escanerPort="-d genesys " si es Cannon 
# rc_escanerPort="-d hp3900" si es hp 
# rc_escanerPort= <<<< asi sin nada toma por defecto a menos que tenga problemas el SO  
rc_escanerPort=" -d genesys "

rc_scannerExtras=
rc_resolution=300
rc_escanerModo=Gray
rc_escanerMarca=Canon
rc_black=45000
rc_white=45000
rc_cropOblea=0x350+0
#-------Defunciones -------------
rc_def_reso=150
rc_def_modo=Color
# solo en wind rc_def_calidad=JPG75
# ----------------------------
rc_def_otrL_crop=97%x55%+0+0
rc_def_otrL_size=50%
#--------------------------
rc_def_dniT_crop=45%x20%+0+0
rc_def_dniT_size=50%
#--------------------------
rc_def_dniL_crop=74%x38%+0+0
rc_def_dniL_size=50%
#--- 22-03-2018 ---------------------
rc_crop_acta=98%x99%+1+1
rc_lat_crop_acta=60x60-9% 
rc_crop_marg=98%x95%+35+25
rc_crop_gen=98%x95%+25+25
rc_acta_lat=50x50-9%
#rc_acta_lat=25x25-10%
#rc_gen_lat=25x25-10%
rc_gen_lat=50x50-9%
rc_marg_lat=50x50-9%
rc_size_marg=59%
#este conf-usuario.sh es para poder sobreescribir la configuracion
source $HOME/$rc_nameRegistro/usuario/conf-usuario.sh

