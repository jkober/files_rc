rc_escanerPort=
# En algun momento el nombre del escaner podria ir ente ' comilla simple
# rc_escanerPort="-d genesys " si es Cannon 
# rc_escanerPort="-d hp3900" si es hp 
# rc_escanerPort= <<<< asi sin nada toma por defecto a menos que tenga problemas el SO  
rc_escanerPort=" -d genesys "

rc_scannerExtras=
rc_resolution=200
rc_escanerModo=Color
rc_escanerMarca=Canon
rc_black=45000
rc_white=45000
rc_cropOblea=0x350+0
#-------Defunciones -------------
rc_def_reso=150
rc_def_modo=Color
# solo en wind rc_def_calidad=JPG75
# ----------------------------
rc_def_otrL_crop=97%x55%+0+0
rc_def_otrL_size=50%
#--------------------------
rc_def_dniT_crop=45%x20%+0+0
rc_def_dniT_size=50%
#--------------------------
rc_def_dniL_crop=74%x38%+0+0
rc_def_dniL_size=50%

#este conf-usuario.sh es para poder sobreescribir la configuracion
source $HOME/$rc_nameRegistro/usuario/conf-usuario.sh

