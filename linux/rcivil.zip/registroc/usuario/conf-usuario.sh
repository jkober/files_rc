#rc_escanerPort=
# En algun momento el nombre del escaner podria ir ente ' comilla simple
# rc_escanerPort="-d genesys " si es Cannon 
# rc_escanerPort="-d hp3900" si es hp 
# rc_escanerPort= <<<< asi sin nada toma por defecto a menos que tenga problemas el SO  
source $HOME/$rc_nameRegistro/usuario/conf-escaner.sh
