#!/bin/bash
rc_nameRegistro=registroc
source $HOME/$rc_nameRegistro/conf/conf-shell.sh
if [ -f $HOME/$rc_nameRegistro/procesando.pid ]
then
   echo "Procesando no se escanea" 
    return 33 
else
    echo $1 >$HOME/$rc_nameRegistro/procesando.pid 
    python usb_r.py Canon
    rm $HOME/$rc_nameRegistro/tmp/*
    #cp $HOME/$rc_nameRegistro/a.tiff $HOME/$rc_nameRegistro/tmp/$1.tiff
    scanimage --mode $rc_def_modo --resolution $rc_def_reso  --format=tiff >$HOME/$rc_nameRegistro/tmp/$1.tiff 
    if [ $? -eq 0 ]
    then
		convert $HOME/$rc_nameRegistro/tmp/$1.tiff -crop $rc_def_otrL_crop -size $rc_def_otrL_size -compress LZW  $HOME/$rc_nameRegistro/tmp/$1-find.jpg
		if [ $? -eq 0 ]
			then
				base64 $HOME/$rc_nameRegistro/tmp/$1-find.jpg > $HOME/$rc_nameRegistro/tmp/$1.json
				echo "bien" > $HOME/$rc_nameRegistro/tmp/$1.fin
				rm $HOME/$rc_nameRegistro/procesando.pid
				exit 0
			else
				echo "mal" > $HOME/$rc_nameRegistro/tmp/$1.fin
				rm $HOME/$rc_nameRegistro/procesando.pid
				exit 88
			fi
	else
        echo "mal" > $HOME/$rc_nameRegistro/tmp/$1.fin
		rm $HOME/$rc_nameRegistro/procesando.pid
		exit 88
    fi
fi
