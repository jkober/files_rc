rc_nameRegistro=registroc
convert -crop "$1" "$HOME/$rc_nameRegistro/tmpMarg/fileToCrop.png" "$HOME/$rc_nameRegistro/tmpMarg/fileFromCrop.png"
base64 $HOME/$rc_nameRegistro/tmpMarg/fileFromCrop.png > $HOME/$rc_nameRegistro/tmpMarg/fileFromCrop.json
convert -crop 50%x0+0+0 $HOME/$rc_nameRegistro/tmpMarg/fileFromCrop.png $HOME/$rc_nameRegistro/tmpMarg/fileFromCrop-Crop.jpg
