#!/bin/bash
export rc_inicia_app_link=true
gnome-terminal -x /bin/bash $HOME/rcdigital-linux/linux.sh
ps -ef | awk '/AppScanners.jar/ && !/awk/ {print $2}'| xargs -r kill -9
java -jar $HOME/linux-java/AppScanners.jar &
##---------------------------------------------------------------
exit 0


